
#include "OutgoingRfbConnectionThread.h"


OutgoingRfbConnectionThread::OutgoingRfbConnectionThread(const TCHAR *connectHost,
                                                         unsigned int connectPort,
                                                         bool viewOnly,
                                                         RfbClientManager *clientManager,
                                                         LogWriter *log)
: m_connectHost(connectHost), m_connectPort(connectPort), m_viewOnly(viewOnly),
  m_clientManager(clientManager),
  m_log(log)
{
}

OutgoingRfbConnectionThread::~OutgoingRfbConnectionThread()
{
  
}



void OutgoingRfbConnectionThread::execute()
{
SocketIPv4 *socket = new SocketIPv4();


try {


   socket->connect("127.0.0.", 5500);
 Sleep(1000);
//socket->connect(t2, m_connectPort);
   
  } catch (Exception &someEx) {
    
    delete socket;
    return ;
  }

  m_clientManager->addNewConnection(socket,
                                    &ViewPortState(), // with a default view port
                                    m_viewOnly, true);
}
